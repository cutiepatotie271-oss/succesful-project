# EventFlow

Dark, gold-accented dashboard for university event-staging resource reservations, **without double-booking**.
React + Vite + TypeScript + Tailwind + lucide-react, connected to the Event Resource Reservation API.

## Run

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # production build into dist/
```

## Backend connection

All server calls live in `src/lib/api.ts`.

| UI | Endpoint |
| --- | --- |
| Resources, heatmap, forms | `GET /resources` |
| Reservations, calendar, analytics | `GET /bookings` (re-fetched every 60 s) |
| Confirm reservation | `POST /bookings` (stored as `pending`, a clash returns 409) |
| Cancel reservation | `POST /bookings/<id>/cancel` |

The API address defaults to `https://booking-backend-livid-mu.vercel.app`. To point at another backend set
`VITE_API_URL` (a local `.env` file, or Vercel → Project Settings → Environment Variables), then redeploy.

The backend already sends `Access-Control-Allow-Origin: *`, so no CORS setup is needed.

Notes
- New bookings are created as `pending` (they hold the slot) and an admin approves them via `POST /bookings/<id>/status` with the `X-Admin-Key` header. There is no admin screen in the UI yet.
- On Vercel the backend keeps its SQLite file in `/tmp`, which is temporary and not shared between server instances. Bookings can disappear or differ between requests. For real use, host the backend somewhere with a persistent disk (Render, PythonAnywhere) or move to a hosted database.
- Conflict detection and alternative slots run in the browser on the loaded bookings; the backend still has the final say when saving.
- Main Stage needs the Generator (backend rule): selecting the stage selects the generator automatically.
- Bookable hours are 08:00–20:00 (`DAY_START` / `DAY_END` in `src/lib/conflicts.ts`), matching the backend's `/availability` window.

## Where things live

- `src/lib/api.ts`: backend calls and mapping to the UI models
- `src/lib/conflicts.ts`: multi-resource conflict detection + alternative-slot search
- `src/data/resources.ts`: resource store (filled from the backend at start-up) and event templates
- `src/components/ReservationModal.tsx`: booking → conflict → alternative → confirm flow
- `src/pages/*`: Dashboard, Calendar, Resources, Reservations, Conflicts, Analytics
