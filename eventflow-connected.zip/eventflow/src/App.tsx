import { useCallback, useEffect, useState } from 'react'
import { AlertTriangle, Loader2 } from 'lucide-react'
import type { Conflict, NewReservation, Page, Prefill, Reservation } from './types'
import { API_URL, cancelBooking, createBooking, fetchReservations, fetchResources } from './lib/api'
import { detectOverlaps } from './lib/conflicts'
import { setResources } from './data/resources'
import { fmtDate } from './lib/date'
import Sidebar from './components/Sidebar'
import Topbar from './components/Topbar'
import ReservationModal from './components/ReservationModal'
import { useToast } from './components/Toast'
import Dashboard from './pages/Dashboard'
import CalendarPage from './pages/CalendarPage'
import Resources from './pages/Resources'
import Reservations from './pages/Reservations'
import Conflicts from './pages/Conflicts'
import Analytics from './pages/Analytics'

type Boot = { state: 'loading' } | { state: 'error'; message: string } | { state: 'ready' }

/** How often the bookings are re-fetched so people booking at the same time see each other. */
const REFRESH_MS = 60_000

const errMsg = (e: unknown) => (e instanceof Error ? e.message : 'Something went wrong.')

/** Overlaps found in the server data (keeping any resolved status) + attempts blocked in this session. */
function mergeConflicts(prev: Conflict[], reservations: Reservation[]): Conflict[] {
  const known = new Map(prev.map((c) => [c.id, c]))
  const overlaps = detectOverlaps(reservations).map((c) => known.get(c.id) ?? c)
  return [...overlaps, ...prev.filter((c) => c.kind === 'blocked')]
}

export default function App() {
  const toast = useToast()
  const [boot, setBoot] = useState<Boot>({ state: 'loading' })
  const [page, setPage] = useState<Page>('dashboard')
  const [reservations, setReservations] = useState<Reservation[]>([])
  const [conflicts, setConflicts] = useState<Conflict[]>([])
  const [modal, setModal] = useState<{ key: number; prefill?: Prefill } | null>(null)
  const [query, setQuery] = useState('')

  const applyReservations = useCallback((list: Reservation[]) => {
    setReservations(list)
    setConflicts((prev) => mergeConflicts(prev, list))
  }, [])

  const refresh = useCallback(async () => {
    try {
      applyReservations(await fetchReservations())
    } catch {
      /* keep showing the last known data; the next refresh will retry */
    }
  }, [applyReservations])

  const load = useCallback(async () => {
    setBoot({ state: 'loading' })
    try {
      const [res, list] = await Promise.all([fetchResources(), fetchReservations()])
      setResources(res)
      applyReservations(list)
      setBoot({ state: 'ready' })
    } catch (e) {
      setBoot({ state: 'error', message: errMsg(e) })
    }
  }, [applyReservations])

  useEffect(() => {
    void load()
  }, [load])

  useEffect(() => {
    if (boot.state !== 'ready') return
    const t = window.setInterval(() => void refresh(), REFRESH_MS)
    return () => window.clearInterval(t)
  }, [boot.state, refresh])

  const openConflicts = conflicts.filter((c) => c.status === 'open').length

  const openBooking = (prefill?: Prefill) => setModal({ key: Date.now(), prefill })

  const handleQuery = (q: string) => {
    setQuery(q)
    if (page !== 'reservations') setPage('reservations')
  }

  // Blocked attempts are logged once (deduped by id) so the Conflicts page tells the story.
  const logConflicts = (incoming: Conflict[]) =>
    setConflicts((prev) => {
      const ids = new Set(prev.map((c) => c.id))
      return [...incoming.filter((c) => !ids.has(c.id)), ...prev]
    })

  /** Save to the backend. Returns true when the booking was stored. */
  const confirmReservation = async (draft: NewReservation, replaceId?: string): Promise<boolean> => {
    try {
      await createBooking(draft)
    } catch (e) {
      toast.push({ type: 'error', title: 'Booking was not saved', message: errMsg(e) })
      await refresh() // someone else may have just taken the slot
      return false
    }

    // Rescheduling = book the new slot first, then cancel the old one (never lose a booking).
    let note: string | undefined
    if (replaceId) {
      try {
        await cancelBooking(replaceId)
      } catch (e) {
        note = `The new slot is booked, but the old booking could not be cancelled: ${errMsg(e)}`
      }
    }
    await refresh()

    // Anything this booking was blocked on (or replaced) is now resolved.
    setConflicts((prev) =>
      prev.map((c) =>
        c.status === 'open' &&
        ((replaceId && c.incomingId === replaceId) || (c.kind === 'blocked' && c.incomingName === draft.event))
          ? { ...c, status: 'resolved' }
          : c,
      ),
    )
    toast.push({
      type: note ? 'info' : 'success',
      title: 'Reservation submitted',
      // The backend stores new bookings as "pending": they hold the slot until an admin approves them.
      message: note ?? `${draft.event} · ${fmtDate(draft.date)}, ${draft.start}–${draft.end}. Slot is held while it awaits admin approval.`,
    })
    return true
  }

  const cancelReservation = async (id: string) => {
    const r = reservations.find((x) => x.id === id)
    try {
      await cancelBooking(id)
    } catch (e) {
      toast.push({ type: 'error', title: 'Could not cancel reservation', message: errMsg(e) })
      return
    }
    setConflicts((prev) => prev.map((c) => (c.status === 'open' && (c.incomingId === id || c.existingId === id) ? { ...c, status: 'resolved' } : c)))
    await refresh()
    toast.push({ type: 'info', title: 'Reservation cancelled', message: r ? `${r.event} was removed and its resources are free again.` : undefined })
  }

  const resolveConflict = (id: string) => {
    setConflicts((prev) => prev.map((c) => (c.id === id ? { ...c, status: 'resolved' } : c)))
    toast.push({ type: 'success', title: 'Conflict marked resolved' })
  }

  if (boot.state !== 'ready') {
    return (
      <div className="flex h-screen items-center justify-center p-6">
        <div className="card max-w-md p-8 text-center">
          {boot.state === 'loading' ? (
            <>
              <Loader2 className="mx-auto h-9 w-9 animate-spin text-gold" />
              <p className="mt-4 text-sm font-semibold text-white">Connecting to the booking server…</p>
              <p className="mt-1 text-xs text-slate-500">The first request can take a few seconds if the server was asleep.</p>
            </>
          ) : (
            <>
              <AlertTriangle className="mx-auto h-9 w-9 text-red-300" />
              <p className="mt-4 text-sm font-semibold text-white">Could not load data</p>
              <p className="mt-2 text-xs leading-relaxed text-slate-400">{boot.message}</p>
              <p className="mt-2 break-all text-[11px] text-slate-600">{API_URL}</p>
              <button onClick={() => void load()} className="btn-gold mt-5">Try again</button>
            </>
          )}
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar page={page} onNavigate={setPage} openConflicts={openConflicts} />
      <div className="flex min-w-0 flex-1 flex-col">
        <Topbar
          page={page}
          query={query}
          onQuery={handleQuery}
          onNew={() => openBooking()}
          openConflicts={openConflicts}
          onBell={() => setPage('conflicts')}
        />
        <main className="flex-1 overflow-y-auto p-6">
          <div className="mx-auto max-w-[1500px]">
            {page === 'dashboard' && <Dashboard reservations={reservations} conflicts={conflicts} onNew={openBooking} onNavigate={setPage} />}
            {page === 'calendar' && <CalendarPage reservations={reservations} conflicts={conflicts} onNew={openBooking} />}
            {page === 'resources' && <Resources reservations={reservations} onNew={openBooking} />}
            {page === 'reservations' && <Reservations reservations={reservations} conflicts={conflicts} query={query} onQuery={setQuery} onCancel={cancelReservation} />}
            {page === 'conflicts' && <Conflicts reservations={reservations} conflicts={conflicts} onNew={openBooking} onResolve={resolveConflict} />}
            {page === 'analytics' && <Analytics reservations={reservations} conflicts={conflicts} />}
          </div>
        </main>
      </div>

      {modal && (
        <ReservationModal
          key={modal.key}
          prefill={modal.prefill}
          reservations={reservations}
          onClose={() => setModal(null)}
          onConfirm={confirmReservation}
          onLogConflicts={logConflicts}
        />
      )}
    </div>
  )
}
