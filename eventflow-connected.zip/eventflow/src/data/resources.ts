import type { EventTemplate, Resource } from '../types'

/**
 * Resources are loaded from the backend (GET /resources) when the app starts, before any
 * page renders, and stored here. `resources` is an ES-module live binding, so every
 * importer sees the loaded list.
 */
export let resources: Resource[] = []

export function setResources(list: Resource[]) {
  resources = list
}

/** Quick-start templates. `resourceNames` are matched against the backend's resource names. */
export const eventTemplates: EventTemplate[] = [
  { id: 'concert', label: 'Concert / Cultural Night', name: 'Cultural Night', hours: 3, resourceNames: ['Main Stage', 'Sound System'] },
  { id: 'conference', label: 'Conference / Keynote', name: 'Tech Conference', hours: 4, resourceNames: ['Auditorium', 'Projector', 'Sound System'] },
  { id: 'lecture', label: 'Lecture / Workshop', name: 'Guest Lecture', hours: 2, resourceNames: ['Seminar Hall', 'Projector'] },
  { id: 'ceremony', label: 'Ceremony', name: 'Awards Ceremony', hours: 3, resourceNames: ['Auditorium', 'Sound System'] },
  { id: 'screening', label: 'Film Screening', name: 'Movie Night', hours: 3, resourceNames: ['Auditorium', 'Projector', 'Sound System'] },
]
