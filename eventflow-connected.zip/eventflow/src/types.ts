export type Page = 'dashboard' | 'calendar' | 'resources' | 'reservations' | 'conflicts' | 'analytics'

// Resource ids come from the backend (numeric ids, kept as strings here).
export type ResourceId = string
export type Category = 'Staging' | 'Power' | 'Audio' | 'Visual' | 'Furniture' | 'Venue' | 'Other'

export interface Resource {
  id: ResourceId
  name: string
  short: string
  category: Category
  description: string
  spec: string
  rules?: string
  /** Another resource that must always be booked together with this one. */
  requiresId?: ResourceId
}

export type ReservationStatus = 'confirmed' | 'pending'

export interface Reservation {
  id: string
  event: string
  organizer: string
  date: string // YYYY-MM-DD
  start: string // HH:mm
  end: string // HH:mm
  resourceIds: ResourceId[]
  status: ReservationStatus
}

export interface Conflict {
  id: string
  resourceId: ResourceId
  date: string
  start: string // overlap window start
  end: string // overlap window end
  existingId: string
  incomingId?: string
  incomingName: string
  incomingStart: string
  incomingEnd: string
  incomingResourceIds: ResourceId[]
  kind: 'overlap' | 'blocked'
  status: 'open' | 'resolved'
  loggedAt: number
}

export interface AvailabilityRequest {
  date: string
  start: string
  end: string
  resourceIds: ResourceId[]
}

export interface ResourceHit {
  resourceId: ResourceId
  reservation: Reservation
}

export interface AltSlot {
  date: string
  start: string
  end: string
  note: string
}

export interface Prefill {
  name?: string
  organizer?: string
  date?: string
  start?: string
  end?: string
  resourceIds?: ResourceId[]
  replaceId?: string
  autoCheck?: boolean
}

export interface EventTemplate {
  id: string
  label: string
  name: string
  hours: number
  /** Resource names (matched against the backend's resource list). */
  resourceNames: string[]
}

/** What the booking form sends to the backend. */
export type NewReservation = Omit<Reservation, 'id' | 'status'>
