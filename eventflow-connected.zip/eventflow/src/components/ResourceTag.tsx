import { Armchair, Boxes, Building2, Monitor, Projector, Theater, Users, Volume2, Zap } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import type { Resource, ResourceId } from '../types'
import { resources } from '../data/resources'

/** Pick an icon from the resource name (resources come from the backend, so there is no fixed id list). */
export function iconFor(id: ResourceId): LucideIcon {
  const n = (resources.find((r) => r.id === id)?.name ?? '').toLowerCase()
  if (n.includes('stage')) return Theater
  if (n.includes('generator') || n.includes('power')) return Zap
  if (n.includes('sound') || n.includes('mic')) return Volume2
  if (n.includes('projector')) return Projector
  if (n.includes('led') || n.includes('display') || n.includes('screen')) return Monitor
  if (n.includes('chair')) return Armchair
  if (n.includes('auditorium')) return Building2
  if (n.includes('seminar') || n.includes('hall') || n.includes('room')) return Users
  return Boxes
}

/** Never throws: a booking may reference a resource that is no longer listed. */
export const resourceById = (id: ResourceId): Resource =>
  resources.find((r) => r.id === id) ?? { id, name: `Resource ${id}`, short: `#${id}`, category: 'Other', description: '', spec: '' }

export function ResourceTag({ id, tone = 'default' }: { id: ResourceId; tone?: 'default' | 'danger' }) {
  const Icon = iconFor(id)
  const cls =
    tone === 'danger'
      ? 'border-red-400/30 bg-red-400/10 text-red-300'
      : 'border-white/10 bg-white/5 text-slate-300'
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-lg border px-2 py-1 text-xs font-medium ${cls}`}>
      <Icon className="h-3.5 w-3.5" />
      {resourceById(id).short}
    </span>
  )
}
