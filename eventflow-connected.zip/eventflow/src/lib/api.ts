import type { Category, NewReservation, Reservation, Resource } from '../types'

/**
 * Backend base URL. Set VITE_API_URL in Vercel (or a local .env file) to change it.
 * Falls back to the deployed booking backend.
 */
export const API_URL = ((import.meta.env.VITE_API_URL as string | undefined) || 'https://booking-backend-livid-mu.vercel.app').replace(/\/+$/, '')

export class ApiError extends Error {
  status: number
  constructor(message: string, status: number) {
    super(message)
    this.name = 'ApiError'
    this.status = status
  }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  // Only send a JSON content-type when there is a body: plain GETs then stay "simple"
  // requests and need no CORS preflight.
  const headers: Record<string, string> = init.body ? { 'Content-Type': 'application/json' } : {}
  let res: Response
  try {
    res = await fetch(`${API_URL}${path}`, { ...init, headers })
  } catch {
    throw new ApiError(
      'Could not reach the booking server. Check your connection, and that the backend allows requests from this site (CORS).',
      0,
    )
  }
  const text = await res.text()
  let body: unknown = null
  try {
    body = text ? JSON.parse(text) : null
  } catch {
    /* non-JSON body */
  }
  if (!res.ok) {
    const b = body as {
      error?: string
      message?: string
      detail?: string
      conflicts?: { resource: string; event_name: string; start: string; end: string }[]
    } | null
    // POST /bookings answers a clash with 409 and a `conflicts` list instead of an `error` text.
    const c = b?.conflicts?.[0]
    const clash = c ? `${c.resource} is already booked by "${c.event_name}" (${c.start.slice(11, 16)}–${c.end.slice(11, 16)}).` : undefined
    throw new ApiError(b?.error || clash || b?.message || b?.detail || `Server returned ${res.status}`, res.status)
  }
  return body as T
}

/* ---------- Backend shapes (see GET /resources and GET /bookings) ---------- */

interface ApiResource {
  id: number
  name: string
  description?: string | null
  location?: string | null
  capacity?: number | null
  rules?: string | null
  requires_id?: number | null
}

interface ApiBooking {
  id: number
  event_name: string
  requester?: string | null
  start: string // "YYYY-MM-DDTHH:MM"
  end: string
  resource_ids: string | number[] | null // "1,2" (comma separated)
  status?: string | null
}

/* ---------- Mapping backend -> UI models ---------- */

function categoryFor(name: string): Category {
  const n = name.toLowerCase()
  if (n.includes('stage')) return 'Staging'
  if (n.includes('generator') || n.includes('power')) return 'Power'
  if (n.includes('sound') || n.includes('mic') || n.includes('speaker')) return 'Audio'
  if (n.includes('projector') || n.includes('led') || n.includes('display') || n.includes('screen')) return 'Visual'
  if (n.includes('chair') || n.includes('table')) return 'Furniture'
  if (n.includes('auditorium') || n.includes('hall') || n.includes('room')) return 'Venue'
  return 'Other'
}

const shortName = (name: string) => name.replace(/^Main /, '').replace(/ System$/, '').replace(/ Hall$/, '')

function mapResource(r: ApiResource): Resource {
  const spec = [r.capacity ? `${r.capacity.toLocaleString()} capacity` : null, r.location].filter(Boolean).join(' · ')
  return {
    id: String(r.id),
    name: r.name,
    short: shortName(r.name),
    category: categoryFor(r.name),
    description: r.description || '',
    spec,
    rules: r.rules || undefined,
    requiresId: r.requires_id != null ? String(r.requires_id) : undefined,
  }
}

function mapBooking(b: ApiBooking): Reservation | null {
  const status = (b.status || '').toLowerCase()
  if (status === 'cancelled' || status === 'canceled' || status === 'rejected') return null
  const ids = Array.isArray(b.resource_ids)
    ? b.resource_ids.map(String)
    : String(b.resource_ids ?? '')
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean)
  const date = b.start.slice(0, 10)
  // The UI works with single-day bookings: clip anything that runs past midnight.
  const end = b.end.slice(0, 10) === date ? b.end.slice(11, 16) : '23:59'
  return {
    id: String(b.id),
    event: b.event_name,
    organizer: b.requester || 'Unknown',
    date,
    start: b.start.slice(11, 16),
    end,
    resourceIds: ids,
    status: status === 'approved' || status === 'confirmed' ? 'confirmed' : 'pending',
  }
}

/* ---------- Calls ---------- */

export async function fetchResources(): Promise<Resource[]> {
  const rows = await request<ApiResource[]>('/resources')
  return rows.map(mapResource)
}

export async function fetchReservations(): Promise<Reservation[]> {
  const rows = await request<ApiBooking[]>('/bookings')
  return rows.flatMap((b) => {
    const r = mapBooking(b)
    return r ? [r] : []
  })
}

/**
 * POST /bookings {event_name, requester, resource_ids: number[], start, end}.
 * The server re-checks for clashes (409 if taken), adds required resources (Main Stage -> Generator)
 * and stores the booking as "pending" until an admin approves it.
 */
export async function createBooking(draft: NewReservation): Promise<void> {
  await request('/bookings', {
    method: 'POST',
    body: JSON.stringify({
      event_name: draft.event,
      requester: draft.organizer,
      start: `${draft.date}T${draft.start}`,
      end: `${draft.date}T${draft.end}`,
      resource_ids: draft.resourceIds.map(Number),
    }),
  })
}

/** POST /bookings/<id>/cancel: the booking becomes "cancelled" and frees its slot. */
export async function cancelBooking(id: string): Promise<void> {
  await request(`/bookings/${encodeURIComponent(id)}/cancel`, { method: 'POST', body: '{}' })
}
